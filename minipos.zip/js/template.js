// JavaScript Document

var site_url;



site_url="http://localhost:8080/minipos/index.php/";


function makedelete(id,page)
{
	
	if(confirm("are you sure you want to delete this item ?"))
	{
		window.location.href=site_url+"Site/delete_invoice/"+id;	
	}
	
}



function clonerow()
{
	//arg.preventDefault();
		var clone=$( ".clonethis:last-child" ).clone();
		no= $('td.no').length+1;
		clone.find("td[class='no']").html(no);
		clone.appendTo( "#SourceWrapper" );		
		clone.find("input[name='item_name[]']").val("");
		clone.find("input[name='qty[]']").val("");		
		clone.find("input[name='price[]']").val("");	
		window.scrollBy(0, 70);
}


function removerform(event)
{
	var target = $(event.target);
	var cl=$(".clonethis").length;
	
	if(cl==1)
	{
	    alert("You cannot remove it");
	}
	else
	{
	target.parent().parent().remove();
	}
}



function searchInvoice()
{	

		$("#data_content").html("<tr><td align='center' colspan='10'><img src='images/loading.gif' alt='loading.....'/></td></tr>");
		var invoice_name=$("#invoice_name").val();
		var data="invoice_name="+invoice_name;

		$.ajax({
				type: "POST",
				url : site_url+"Site/searchInvoice",
				data : data,
				success : function(e)
				{
					$("#data_content").html(e);
				}
			
			});
	
}

