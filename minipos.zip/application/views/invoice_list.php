
                            <?php $no=1; foreach($lists->result() as $list){ ?>
                            <tr>
                                <td><?=$no?></td>
                                <td><?php echo anchor("Site/edit_invoice_form/".$list->id,$list->invoice_name);?>
                                 </td>
                                <td><?=$list->total_item?> </td>
                                <td><?=$list->net_total?> </td>                               
                                
                                <td>
                                 <?php echo anchor("Site/invoice_detail/".$list->id,"<i class='fa fa-eye'></i>");?> &nbsp; &nbsp;
                                 <a href="javascript:makedelete('<?=$list->id?>')">Remove </a>
                                </td>                                                        
                            </tr>
                          <?php $no++; } ?>
                          