    
    <div class="row">
        
            <h4 style="color: green; text-align: center;margin-bottom: 20px"><?php if($this->uri->segment(4)=="success")
            {
              echo "Successfully Updated";
            }?></h4>
    </div>
   
<!--                 <div class="box-body">
 -->                        
              

                   <div class="row-fluid"> 
                    
                           
                                <div class="col-md-2">
<!--                                     
 -->                              <input type="text" name="invoice_name" id="invoice_name" class="form-control">
                                        <span class="text-danger"><?php echo form_error('online_workbook_name'); ?></span>
                                </div>

                                

                                <div class="col-md-1"> 
                                                
                                        <input type="button" class="btn btn-warning" onclick="searchInvoice()" value="Search" name="search">
                                        <span class="text-danger"><?php echo form_error('search'); ?></span>
                                </div>
                                
                             

                                <div class="col-md-4 text-right">
                                  <?=anchor("Site/invoice_form","<i class='fa fa-plus'> Add Invoice</i>","class='btn btn-success'")?>;                                   
                                </div>
                                
                            </div>   

                                                
                    <!-- </div> -->

                      <br/> <br/>
                        
                          <div class="row-fluid">

                          <table class="table table-striped" id="center-content">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Invoice Name</th>  
                                <th>#of Items </th>
                                <th>Total </th>                                      
                            </tr>
                          </thead>

                          <tbody id="data_content">

                            <?php $no=1; foreach($lists->result() as $list){ ?>
                            <tr>
                                <td><?=$no?></td>
                                <td><?php echo anchor("Site/edit_invoice_form/".$list->id,$list->invoice_name);?>
                                 </td>
                                <td><?=$list->total_item?> </td>
                                <td><?=$list->net_total?> </td>                               
                                
                                <td>
                                 <?php echo anchor("Site/invoice_detail/".$list->id,"<i class='fa fa-eye'></i>");?> &nbsp; &nbsp;
                                 <a href="javascript:makedelete('<?=$list->id?>')">Remove </a>
                                </td>                                                        
                            </tr>
                          <?php $no++; } ?>
                           
                          </tbody>
                        </table>

                      </div>
                   
             