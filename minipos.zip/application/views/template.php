    <html>
    <head>
      <title> Mini Pos </title>
      
      <base href="<?=base_url()?>"></base>
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> 
      <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <script type="text/javascript" src="js/template.js"></script>
      <script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
    <style type="text/css">
      .paid
      {
        color:green;
        font-weight: bold;
      }
      .bal
      {
        color:#ce9523;
        font-weight: bold;
      }

      #data_content a
      {
        text-decoration: underline;
      }

      .clonethis .form-control
      {
       
        width: 80% !important;
      }

      .fa-trash-o
      {
        font-size: 18px;
      }

      tr
      {
        line-height: 3;
      }

      .invoicename
      {
/*        display: block;
*/        height: 34px;
        padding: 6px 12px;
        font-size: 14px;
        line-height: 1.428571429;
        color: #555;
        background-color: #fff;
        background-image: none;
        border: 1px solid #ccc;
        border-radius: 4px;
        -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
        box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
        -webkit-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
      }

      .container
      {
        width: 1000px;
      }

     /* .btn-warning
      {
        margin-top: 25px;
      }*/
    </style>

    </head>


    <body>
        <div class="container">
          <?php $this->load->view($content);?>
        </div>
    </body>

  </html>