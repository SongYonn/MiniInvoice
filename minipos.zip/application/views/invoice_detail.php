
    <div class="row">
        <h3> Invoice Detail </h3> <?=anchor("Site","Go Home","class='btn btn-success'")?>
        <br/>    
    </div>
    <br/>
    
    <div class="row"> 

        
            <label> Invoice Name</label>        
      
                
            <?=form_input("invoice_name",$row->invoice_name,"class='invoicename'")?>
            <span class="text-danger"><?php echo form_error('invoice_name'); ?></span>
        

    </div> 


    
      <table class="" width="100%">

          <thead>
            <tr>
                <th>Item Name</th>
                <th># of items</th>
                <th>Price</th>
                
            </tr>
        </thead>
        <br/>
        <tbody id="SourceWrapper">

        <?php foreach($lists->result() as $list){ ?>
          <tr class="clonethis">
             
         <td>
            <div class="form-group">
            <?php echo form_input("item_name[]",$list->item_name,'class="form-control"'); ?>

            </div> 

         </td>

         <td>
            <div class="form-group">
            <?php echo form_input("qty[]",$list->qty,'class="form-control"'); ?>

            </div> 

         </td>


        <td>
            <div class="form-group">
            <?php echo form_input("price[]",$list->price,'class="form-control"'); ?>

            </div> 

         </td>




    <td align="center" width="5%"><a onclick="removerform(event)"><i class="fa fa-trash-o"></i></a></td>
    </tr>

    <?php } ?>

    
    </tbody>
  
    </table>

    <div class="row">
        <div class="col-md-6"></div>
        <div class="col-md-2 text-right">
            Grand total
        </div>

        <div class="col-md-2">
            <input type="text" name="tax" value="<?=$row->grand_total?>" placeholder="Eg. 5%" class="form-control">
        </div>
        <div class="col-md-1"></div>
    </div> <br/>

    <div class="row">
        <div class="col-md-6"></div>
        <div class="col-md-2 text-right">
            Tax
        </div>

        <div class="col-md-2">
            <input type="text" name="tax" value="<?=$row->tax?>" placeholder="Eg. 5%" class="form-control">
        </div>
        <div class="col-md-1"></div>
    </div> <br/>

    <div class="row">
        <div class="col-md-6"></div>
        <div class="col-md-2 text-right">
            Net Total
        </div>

        <div class="col-md-2">
            <input type="text" name="net_total" value="<?=$row->net_total?>" placeholder="Eg. 5%" class="form-control">
        </div>
        <div class="col-md-1"></div>
    </div>

    
    <br/> <br/>

    
    <br/>

