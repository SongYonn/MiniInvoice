
    <div class="row">
        <h3> New Invoice </h3>
        <br/>    
    </div>
    <?=form_open("Site/create_invoice","")?>

    <div class="row"> 

        
            <label> Invoice Name</label>        
      
                
            <?=form_input("invoice_name","","class='invoicename'")?>
            <span class="text-danger"><?php echo form_error('invoice_name'); ?></span>
        

    </div> 


    <div class="row clone">
      <table class="" width="100%">

          <thead>
            <tr>
                <th>Item Name</th>
                <th># of items</th>
                <th>Price</th>
                
            </tr>
        </thead>
        <br/>
        <tbody id="SourceWrapper">

          <tr class="clonethis">
             
         <td>
            <div class="form-group">
            <?php echo form_input("item_name[]",'','class="form-control"'); ?>

            </div> 

         </td>

         <td>
            <div class="form-group">
            <?php echo form_input("qty[]",'','class="form-control"'); ?>

            </div> 

         </td>


        <td>
            <div class="form-group">
            <?php echo form_input("price[]",'','class="form-control"'); ?>

            </div> 

         </td>




    <td align="center" width="5%"><a onclick="removerform(event)"><i class="fa fa-trash-o"></i></a></td>
    </tr>

    
    </tbody>
    
    <tr>
        <td> <a onclick="clonerow()" class="btn btn-default"><i class="fa fa-plus"></i> Add Item</a></td>
    </tr>


    </table>

    </div>  
    <div class="row">
        <div class="col-md-7"></div>
        <div class="col-md-1 text-right">
            Tax
        </div>

        <div class="col-md-3">
            <input type="text" name="tax" placeholder="Eg. 5%" class="form-control">
        </div>
        <div class="col-md-1"></div>
    </div>
    <br/> <br/>

    <div class="row">
        <div class="col-md-4">
        
            <input type="submit" name="create" value="Create" class="btn btn-default">
        </div>
        
    </div>

    <?=form_close();?> 
    <br/>

