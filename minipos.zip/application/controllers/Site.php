<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

	  function __construct()
	  {
	  	parent::__construct();
	  	$this->load->model("Main_model");
	  	error_reporting(1);
	  }

		public function index()
		{
			$data["lists"]=$this->Main_model->data_list('invoice');
			$data["content"]="invoice";
			$this->load->view('template',$data);
		}


		function searchInvoice()
		{
			$invoice_name=$this->input->post("invoice_name");
			$data["lists"]=$this->db->query("SELECT * FROM invoice WHERE invoice_name LIKE '%$invoice_name%'");
			$this->load->view('invoice_list',$data);
		}


		function delete_invoice()
		{
			$id=$this->uri->segment(3);
			$this->db->where("id",$id);
			$qry=$this->db->delete("invoice");
			if($qry)
			{
				redirect("Site");
			}
		}

		function invoice_detail()
		{
			$id=$this->uri->segment(3);
			$data["row"]=$this->Main_model->getdata($id);
			$data["lists"]=$this->Main_model->getdatalist($id);
			$data["content"]="invoice_detail";
			$this->load->view('template',$data);
		}

		function invoice_form()
		{
			$data["content"]="invoice_form";
			$this->load->view('template',$data);
		}

		function edit_invoice_form()
		{
			$id=$this->uri->segment(3);
			$data["row"]=$this->Main_model->getdata($id);
			$data["lists"]=$this->Main_model->getdatalist($id);
			$data["content"]="edit_invoice_form";
			$this->load->view('template',$data);
		}

		function create_invoice()
		{
			$grand_total=0;
			$net_total=0;
			$invoice_name=$this->input->post("invoice_name");
			$total_item=count($this->input->post("item_name"));
			$item_name=$this->input->post("item_name");
			$qty=$this->input->post("qty");
			$price=$this->input->post("price");
			$taxpercent=$this->input->post("tax");
			$tpercent=explode("%", $taxpercent);
			for($i=0;$i<$total_item;$i++)
			{
				$p=$price[$i];
				$q=$qty[$i];
				$c=$p*$q;
				$grand_total+=$c;
			}
			$tax=($tpercent[0]/100) * $grand_total;
			$net_total=$grand_total + $tax;

			$data=array("invoice_name"=>$invoice_name,
						"total_item"=>$total_item,
						"grand_total"=>$grand_total,
						"tax"=>$taxpercent,
						"net_total"=>$net_total
			);
			$qry=$this->db->insert("invoice",$data);
			$invoice_id=$this->db->insert_id();
			if($qry)
			{
				for($i=0;$i<$total_item;$i++)
					{
						$detail=array(	"invoice_id"=>$invoice_id,
										"item_name"=>$item_name[$i],
									  	"qty"=>$qty[$i],
									  	"price"=>$price[$i]
						);
						$this->db->insert("invoice_detail",$detail);
					}

			 redirect("Site");

			}
			
		}


		function update_invoice()
		{
			$id=$this->input->post("id");
			$grand_total=0;
			$net_total=0;
			$invoice_name=$this->input->post("invoice_name");
			$total_item=count($this->input->post("item_name"));
			$item_name=$this->input->post("item_name");
			$qty=$this->input->post("qty");
			$price=$this->input->post("price");
			$taxpercent=$this->input->post("tax");
			$tpercent=explode("%", $taxpercent);
			for($i=0;$i<$total_item;$i++)
			{
				$p=$price[$i];
				$q=$qty[$i];
				$c=$p*$q;
				$grand_total+=$c;
			}
			$tax=($tpercent[0]/100) * $grand_total;
			$net_total=$grand_total + $tax;

			$data=array("invoice_name"=>$invoice_name,
						"total_item"=>$total_item,
						"grand_total"=>$grand_total,
						"tax"=>$taxpercent,
						"net_total"=>$net_total
			);
			$this->db->where("id",$id);
			$qry=$this->db->update("invoice",$data);
			$invoice_id=$id;
			if($qry)
			{
				$this->db->where("invoice_id",$id);
				$this->db->delete("invoice_detail");

				for($i=0;$i<$total_item;$i++)
					{
						$detail=array(	"invoice_id"=>$invoice_id,
										"item_name"=>$item_name[$i],
									  	"qty"=>$qty[$i],
									  	"price"=>$price[$i]
						);
						$this->db->insert("invoice_detail",$detail);
					}

				 redirect("Site");

			}	
		
		}
}
