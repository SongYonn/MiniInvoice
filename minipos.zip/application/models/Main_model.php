<?php 
class Main_model extends CI_Model
{
/*Check valid data*/

	function getdata($id)
	{
		$row=$this->db->get_where("invoice",array("id"=>$id))->row();
		return $row;
	}
	
	function getdatalist($id)
	{
		$this->db->where("invoice_id",$id);
		$query=$this->db->get("invoice_detail");
		return $query;
	}

	function data_list($table)
	{

	$config["base_url"]=base_url()."index.php/Site/";	
	$config['total_rows'] = $this->db->get($table)->num_rows();
	$config['per_page'] = 5;
	$config['uri_segment'] = 3;
	$config['num_links'] = 5;	
	$config['full_tag_open'] = '<ul class="list-inline list-unstyled">';
	$config['full_tag_close'] = '</ul>';
	$config['num_tag_open'] = '<li>';
	$config['num_tag_close'] = '</li>';
	$config['cur_tag_open'] = '<li class="active"><a>';
	$config['cur_tag_close'] = '</a></li>';
	$config['prev_tag_open'] = '<li class="prev">';
	$config['prev_tag_close'] = '</li>';
	$config['next_tag_open'] = '<li class="next">';
	$config['next_tag_close'] = '</li>';
	$config['prev_link'] = '<i class="fa fa-angle-left"></i>';
	$config['next_link'] = '<i class="fa fa-angle-right"></i>';
	
	
	$this->pagination->initialize($config);	
	$this->db->order_by('id','DESC');
	
	
		$query = $this->db->get($table,$config['per_page'],$this->uri->segment(4));
	
	return $query;
			
	}


}
 ?>